let parameterType = function(parameter){
    console.log(typeof(parameter));
    return typeof(parameter);
}
 let prashanje;
parameterType(7489237);
parameterType(null);
parameterType(`I am rocking this functions stuff`);
parameterType(false);
parameterType(prashanje);

parameterType(prompt("Vnesi za shto sakash da ti se odredi tipot?")); // pak zaboraviv deka vrakja string sekogash :D  


let humanOrDogYears=prompt(`Whose age are you entering? (human or dog)`);;
let age = Number(prompt(`What is the age?`));; 
const humanToDogYears=7;

function humanDogDifference (age, humanOrDog){
 
    switch(humanOrDog){
        case "dog":
            {
                console.log(`The age in human years is ${age/humanToDogYears} `);
            return age/humanToDogYears; // ako ne se lazham, tuka ne treba break zoshto return odma ja zavrshuva funkcijata?
            }
        case "human": {

console.log(`The age in dog years is ${age*humanToDogYears}`);
return age*humanToDogYears;
}
default:
    console.log(`You didn't enter a valid argument`);
    break;
    // ili return -1;

        

    
    }
}

humanDogDifference(age, humanOrDogYears);

moneyRequested = Number(prompt(`What is the amount of money you want to withdraw?`));
let ATM = function(moneyRequested){
    let moneyInPosession = 1463; 
    if(moneyRequested>moneyInPosession)
        return console.log(`You don't have that amount of money on your account`);
        else if (moneyRequested<=moneyInPosession)
        {
            moneyInPosession -= moneyRequested;
            return console.log(`There is your money, you now have ${moneyInPosession} dollars left`); 
        }
else console.log(`You entered an invalid number`);
return -1;
        



}

ATM(moneyRequested);










