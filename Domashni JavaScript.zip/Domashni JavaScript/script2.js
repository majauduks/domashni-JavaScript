//1

console.log(`Zadacha 1`);
let minutes=Number(prompt(`Kolku minuti imash?`));
let minToSecConst=60;



let minToSec = minutes => console.log(`The ${minutes} you entered are exactly ${minutes*minToSecConst} seconds`);

if (isNaN(minutes))

    console.log('Enter a valid number');
    else
minToSec(minutes);

//2
console.log(`Zadacha 2`);
let number=Number(prompt(`Vnesi broj`));
let increasedInteger = number => console.log(`Tvojot segashen broj e ${number+1}!`);


if (isNaN(number))
    console.log('Enter a valid number');

else
increasedInteger(number);


// 3

console.log(`Zadacha 3`);
function hoursToSeconds (hours)
{
let h2s=3600;
console.log(hours*h2s);
return hours*h2s;
}

hoursToSeconds(2);

// 4
console.log(`Zadacha 4`);
let remainder = function(num1, num2)
{
    return console.log(num1%num2);
}

remainder(-21, 4);


// 5
console.log(`Zadacha 5`);
let chickens=Number(prompt('How many chickens do you have?'));
let cows=Number(prompt('How many cows do you have?'));
let pigs=Number(prompt('How many pigs do you have?'));
function legCount(chickens, cows, pigs){

    let sumOfLegs;

if (isNaN(chickens) || isNaN(cows) || isNaN(pigs)){
console.log('You entered an invalid number');
return -1;
}
else{
    sumOfLegs=2*chickens+4*(cows+pigs);
    console.log(`The number of legs is ${sumOfLegs}`);
    return sumOfLegs;
}
}


legCount(chickens, cows, pigs);


// 6

console.log(`Zadacha 6`);
let array1=prompt('Enter the first array');
let array2=prompt('Enter the second array');

arrayLenght(array1, array2);
function arrayLenght(array1, array2)
{
   let length1=array1.length; 
   let length2=array2.length;
   if(length1===length2)
   {
       console.log('The length is the same');
   return 1;}

   else {
       console.log('The length is not the same');
   }return 0;
}

// 7

console.log(`Zadacha 7`);
let word=prompt('Enter the word');

function allLetter(inputtxt)
  {
   let letters = /^[A-Za-z]+$/;
   if(inputtxt.match(letters))
    return true;
   
  }

function isPLural(word)
{
    if(allLetter(word))
    {
    if(word.endsWith('s'))
    {
        console.log(`The word is a plural form`);
        return 1;
    }
    else {
        console.log(`The word is singular`);
        return 0;
    }
} 
    else {
        console.log('You entered an invalid word');
        return -1;
    }
}





isPLural(word); 



// 8 
console.log(`Zadacha 8`);

let string1=prompt("Write the first string");
let string2=prompt(`Write the second string`);

function areEqual (string1, string2){

string1.toLowerCase();
string2.toLowerCase();

if (string1===string2)
{ 
    console.log(`They are the very same`);
    return 1;}

else{
    console.log(`theyre not the same`);
 return 0;
}
}


areEqual(string1, string2);



// 9
console.log(`Zadacha 9`);
let number=parseInt(prompt('Enter the number of the month'));
let monthNumer = function (inputNumber)
{
    switch (inputNumber){
    case 1:
        console.log(`The month you are looking for is January`);
        break;
        case 2:
        console.log(`The month you are looking for is February`);
        break;
        case 3:
        console.log(`The month you are looking for is March`);
        break;
        case 4:
        console.log(`The month you are looking for is April`);
        break;
        case 5:
        console.log(`The month you are looking for is May`);
        break;
        case 6:
        console.log(`The month you are looking for is June`);
        break;
        case 7:
        console.log(`The month you are looking for is July`);
        break;
        case 8:
        console.log(`The month you are looking for is August`);
        break;
        case 9:
        console.log(`The month you are looking for is September`);
        break;
        case 10:
        console.log(`The month you are looking for is October`);
        break;
        case 11:
        console.log(`The month you are looking for is November`);
        break;
        case 12:
        console.log(`The month you are looking for is December`);
        break;

        default: 
        console.log(`A month with that number does not exist`);
        break;
    }
}

monthNumer(number);


// 10
console.log(`Zadacha 10`);
function truthyOrFalsey (inputUser){
    if (inputUser == 0 ||inputUser == '" "' || inputUser == undefined || inputUser == null || (typeof(inputUser)=='number' && isNaN(inputUser))) {
       console.log('This is a falsey value');
   return 0;
}
else {
    console.log('This is a truthy value, hooray');
    return 1;
}
}

let inputUser=prompt('What do you want to check?');

truthyOrFalsey(inputUser);
let maja=Number('jkfdsahjif');
truthyOrFalsey(Number(maja));
truthyOrFalsey(NaN);
truthyOrFalsey("emptystring");
truthyOrFalsey(null);
truthyOrFalsey( );
truthyOrFalsey("456");
truthyOrFalsey()
truthyOrFalsey(0);
truthyOrFalsey('0');



